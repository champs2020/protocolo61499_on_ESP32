<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1698053464149'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/agent/workspace/4diac IDE Release/plugins/org.eclipse.fordiac.ide.product/target/products/org.eclipse.fordiac.ide.product/win32/win32/x86_64/4diac-ide'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/agent/workspace/4diac IDE Release/plugins/org.eclipse.fordiac.ide.product/target/products/org.eclipse.fordiac.ide.product/win32/win32/x86_64/4diac-ide'/>
  </properties>
</profile>
